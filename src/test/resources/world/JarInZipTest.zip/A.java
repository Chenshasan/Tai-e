import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

class A {
    public static void main(String[] args) throws IOException {
        Path p = Paths.get("a.zip");
        FileSystem fs = FileSystems.newFileSystem(p);
        Path p1 = fs.getPath("/a.txt");
        System.out.println(p1);
        fs.close();
        System.out.println(Files.readAllBytes(p1));
    }
}